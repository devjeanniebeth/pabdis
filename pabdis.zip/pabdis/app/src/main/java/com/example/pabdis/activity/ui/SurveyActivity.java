package com.example.pabdis.activity.ui;

import android.support.v7.app.AppCompatActivity;

public class SurveyActivity extends AppCompatActivity {
}
